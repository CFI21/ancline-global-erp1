import { Controller, Get } from '@nestjs/common';
@Controller('health')
export class HealthController {
  @Get() getHealth(){ return { status:'online', service:'ANCLINE API', phase:'production-phase-1' }; }
}
